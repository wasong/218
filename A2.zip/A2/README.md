###Assignment 2
####Andrew Song 301232704

## Working Features
- add users to form
- remove user from form
- save multiple users
- clear database
- persistent data
- show raw .json
- navigate to users.html

## WIP
- remove user from database
- save multiple properties of a user ie.email
- edit a user

## Notes
- the users.json file is being updated correctly, but the browser or server seems to be caching the file and does not serve the updated file after the initial POST request
